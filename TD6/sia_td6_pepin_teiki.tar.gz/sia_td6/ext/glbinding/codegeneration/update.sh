#!/bin/bash

python scripts/update.py -f gl.xml -r gl.revision
