#pragma once

void glew_init();
void glew_test();

void glew_error(bool enable);
